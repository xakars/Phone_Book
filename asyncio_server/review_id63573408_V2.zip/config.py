host = "127.0.0.1"
user = "postgres"
password = "qwerty"
db_name = "bot_users"
